
# Advance Discord Music Bot Like Rythm Bot

This Discord Bot Made By Tomato6969 




## Installation and How to Use

 **1.** Install [node.js v12+](https://nodejs.org/en/download/) or higher

 **2.** Download this repo and unzip it    |    or git clone it

 **3.** Install all of the packages with **`npm install`**     |  the important packages are   **`npm install discord.js erela.js enmap ascii-table erela.js-deezer erela.js-spotify ms colors @ksoft/api`**

 **4** Fill in the parameters, RIGHT in `botconfig/config.json`!

 **5.** [Download Lavalink](https://cdn.discordapp.com/attachments/798196676405755905/827174915714711572/Lavalink.jar) and download Java 15 (Java 13 recommended)

 **5.1** Run the Lavalink file with: **`java -jar Lavalink.jar`**

 **MAKE SURE THAT THERE IS THE `application.yml` FILE OTHERWISE IT WILL NOT WORK!

 **6.** start the bot with **`start.bat`**
    ## Windows start Command .bat file
```bat
@ECHO OFF
ECHO ==========================
ECHO Starting Lavalink
ECHO ==========================
start cmd /k java -jar ./Lavalink.jar
ECHO ==========================
@ECHO Taking a 5 Second Break for Lavalink
ECHO ==========================
timeout /T 5 /nobreak
ECHO ==========================
@ECHO Starting BOT
ECHO ==========================
start cmd /k node .
exit /s'
```
Windows `start.bat` file
Which starts Lavalink and the Bot together via one click ;)

Have it in the Same folder as `index.js` and `Lavalink.jar`



## **Credits**

[@tomato](https://github.com/Tomato6966/) For the Reacting system to messages, great Idea, I adopted that [@Tomato6966/Rythm-MUSIC](https://github.com/Tomato6966/Milrato-x-Rythm)


Thanks For Tomato6966
Check Out Tomato6966 Gtihub Repo
